var featuredRoomList;
var mainContainer;

document.addEventListener('DOMContentLoaded', () => {
  featuredRoomList = document.getElementById('featured-room-list');
  mainContainer = document.getElementById('container');
});
