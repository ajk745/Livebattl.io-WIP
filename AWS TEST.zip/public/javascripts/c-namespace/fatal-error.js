socket.on('fatal-error', () => {
  window.location.reload(true);
});
